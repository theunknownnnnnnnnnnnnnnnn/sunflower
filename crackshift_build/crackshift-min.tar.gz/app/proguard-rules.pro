# CRACKSHIFT intentionally has no reflection-heavy libraries in v1.
